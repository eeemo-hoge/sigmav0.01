I needed discprine so that is why I wrote this. I will add some more feture when I am free. 
This is just simple version to do not lose foucs.
Use this with task scheduler of windows software or something.


・Liscense
1.I won't gather your personal info.
2.Commercial purpose allowed.
3.I do not take any responsibility not matter what happened.
4.Programm written by non-native english speaker.