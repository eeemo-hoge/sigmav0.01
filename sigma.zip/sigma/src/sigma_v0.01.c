#include<stdio.h>
int main(){
int yourself = 0;
int empty = 0;
    printf("1.work\n");
    printf("2.sleep\n");
    printf("3.chore\n");
    printf("4.chatting.\n");
    printf("5.sleep\n");
    printf("6.chore\n");
    printf("7.others\n");
    scanf("%d",&yourself);
    if(yourself <= 3 ){
        printf("fine. keep going.\n");
        scanf("%d",&empty);
    }else{
        printf("tf r u DOING!!\n");
        printf("u forgotten what happend!? VICTIM NEED TO BE A SIGMA\n");
        scanf("%d",&empty);
     }
return 0;
}
