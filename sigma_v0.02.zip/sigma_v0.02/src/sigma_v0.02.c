#include<stdio.h>
int main(){
int yourself = 0;
int empty = 0;
    printf("1.work\n");
    printf("2.sleep\n");
    printf("3.chore\n");
    printf("4.chore.\n");
    printf("5.chatting\n");
    printf("6.others\n");
    printf("7.Shut a fuking up I understand because i am me\n");
    scanf("%d",&yourself);
    if(yourself <= 3 ){
        printf("Good keep going.\n");
        printf("Press ctrl+c to terminate...\n");
        scanf("%d",&empty);
    }else if(yourself <= 6){
        printf("Be a SIGMA or be a VICTIM... You can chose...\nRizz is temporary...And you CAN NOT GET THE ONE\n");
        printf("Press ctrl+c to terminate...\n");
        scanf("%d",&empty);
         
     }else{
        printf("Do unity, organize, read books randaomly from your shelf.\nTalk to someone on VRC randomly\n");
        printf("Say it what you see in your room\n");
        printf("Eat gum\n");
        printf("Press ctrl+c to terminate...\n");
        scanf("%d",&empty);
     }
return 0;
}
